WITH customer_sales AS (
    SELECT
        customer_id,
        SUM(total_sales_amount) AS total_sales
    FROM {{ ref('transformed_sales_data') }}
    WHERE order_year = 2023
    GROUP BY customer_id
)
SELECT customer_id, total_sales
FROM customer_sales
ORDER BY total_sales DESC
LIMIT 5
