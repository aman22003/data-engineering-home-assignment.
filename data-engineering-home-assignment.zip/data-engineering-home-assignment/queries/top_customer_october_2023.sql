WITH october_sales AS (
    SELECT
        customer_id,
        COUNT(order_id) AS order_volume
    FROM {{ ref('transformed_sales_data') }}
    WHERE order_year = 2023
      AND EXTRACT(MONTH FROM order_date) = 10
    GROUP BY customer_id
)
SELECT customer_id, order_volume
FROM october_sales
ORDER BY order_volume DESC
LIMIT 1