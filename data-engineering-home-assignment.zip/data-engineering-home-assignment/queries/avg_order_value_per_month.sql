WITH monthly_sales AS (
    SELECT
        EXTRACT(MONTH FROM order_date) AS month,
        AVG(total_sales_amount) AS avg_order_value
    FROM {{ ref('transformed_sales_data') }}
    WHERE order_year = 2023
    GROUP BY month
)
SELECT month, avg_order_value
FROM monthly_sales
ORDER BY month
