WITH transformed AS (
    SELECT
        order_id,
        product_id,
        customer_id,
        CAST(order_date AS DATE) AS order_date,  -- Convert order_date to DATE
        EXTRACT(YEAR FROM CAST(order_date AS DATE)) AS order_year,
        EXTRACT(MONTH FROM CAST(order_date AS DATE)) AS order_month,
        EXTRACT(DAY FROM CAST(order_date AS DATE)) AS order_day,
        quantity * PRICE AS total_sales_amount
    FROM {{ ref('sales') }}
)
SELECT * FROM transformed
